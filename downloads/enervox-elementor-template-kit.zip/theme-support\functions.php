<?php
/**
 * Enervox Energy Theme Functions
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

function enervox_enqueue_scripts() {
    // Parent theme styles (Hello Elementor)
    wp_enqueue_style('hello-elementor-parent-style', get_template_directory_uri() . '/style.css');

    // Child theme styles
    wp_enqueue_style(
        'enervox-style',
        get_stylesheet_directory_uri() . '/style.css',
        ['hello-elementor-parent-style'],
        '1.0.0'
    );

    // Dark / Light Mode Switcher Script
    wp_enqueue_script(
        'enervox-dark-mode-toggle',
        get_stylesheet_directory_uri() . '/dark-mode-toggle.js',
        [],
        '1.0.0',
        true
    );
}
add_action('wp_enqueue_scripts', 'enervox_enqueue_scripts', 20);

/**
 * Register custom shortcode for the Light / Dark theme toggle button
 * Usage in Elementor: [enervox_theme_toggle]
 */
function enervox_theme_toggle_shortcode($atts) {
    $atts = shortcode_atts([
        'class' => '',
    ], $atts, 'enervox_theme_toggle');

    return '<button type="button" class="enervox-theme-toggle ' . esc_attr($atts['class']) . '" aria-label="Toggle Theme" title="Toggle Light/Dark Theme">
        <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z"/></svg>
    </button>';
}
add_shortcode('enervox_theme_toggle', 'enervox_theme_toggle_shortcode');

/**
 * Register custom shortcode for the official Penta Services Footer Credit Bar
 * Usage in Elementor: [penta_credit_bar]
 */
function penta_credit_bar_shortcode() {
    $logo_url = get_stylesheet_directory_uri() . '/images/brand/penta-services-logo.svg';

    ob_start();
    ?>
    <div class="enervox-credit-bar">
        <span>Website designed &amp; developed by</span>
        <a href="https://pentaservices.co.uk/en/?utm_source=referral&amp;utm_medium=site-credit" target="_blank" rel="noopener noreferrer" title="Penta Services: web design, development, SEO &amp; AI" class="credit-badge">
            <img src="<?php echo esc_url($logo_url); ?>" alt="Penta Services" width="94" height="40" />
        </a>
        <span>Web design, SEO &amp; digital solutions · <a href="https://pentaservices.co.uk/en/?utm_source=referral&amp;utm_medium=site-credit" target="_blank" rel="noopener noreferrer" class="credit-link">pentaservices.co.uk</a></span>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode('penta_credit_bar', 'penta_credit_bar_shortcode');
