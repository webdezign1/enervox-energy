/**
 * Enervox Energy - Light / Dark Theme Switcher
 * Persists theme in localStorage and respects prefers-color-scheme
 */
(function () {
  function initTheme() {
    const savedTheme = localStorage.getItem('enervox_theme');
    const prefersDark = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
    const isDark = savedTheme === 'dark' || (!savedTheme && prefersDark);

    if (isDark) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }

    updateToggleIcons(isDark);
  }

  function toggleTheme() {
    const isCurrentlyDark = document.documentElement.classList.contains('dark');
    const newDark = !isCurrentlyDark;

    if (newDark) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('enervox_theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('enervox_theme', 'light');
    }

    updateToggleIcons(newDark);
  }

  function updateToggleIcons(isDark) {
    const toggles = document.querySelectorAll('.enervox-theme-toggle');
    toggles.forEach(function (btn) {
      btn.setAttribute('aria-label', isDark ? 'Switch to Light Mode' : 'Switch to Dark Mode');
      btn.setAttribute('title', isDark ? 'Switch to Light Mode' : 'Switch to Dark Mode');

      if (isDark) {
        // Sun Icon (when dark, click to switch to light)
        btn.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="4"/><path d="M12 2v2"/><path d="M12 20v2"/><path d="m4.93 4.93 1.41 1.41"/><path d="m17.66 17.66 1.41 1.41"/><path d="M2 12h2"/><path d="M20 12h2"/><path d="m6.34 17.66-1.41 1.41"/><path d="m19.07 4.93-1.41 1.41"/></svg>';
      } else {
        // Moon Icon (when light, click to switch to dark)
        btn.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z"/></svg>';
      }
    });
  }

  // Run on initial load
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function () {
      initTheme();
      document.addEventListener('click', function (e) {
        const toggle = e.target.closest('.enervox-theme-toggle');
        if (toggle) {
          e.preventDefault();
          toggleTheme();
        }
      });
    });
  } else {
    initTheme();
    document.addEventListener('click', function (e) {
      const toggle = e.target.closest('.enervox-theme-toggle');
      if (toggle) {
        e.preventDefault();
        toggleTheme();
      }
    });
  }

  window.enervoxToggleTheme = toggleTheme;
})();
