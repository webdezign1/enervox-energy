# Enervox Energy — Elementor WordPress Template Kit

This package converts the **Enervox Energy** clean tech web platform into 100% editable WordPress Elementor templates. Every section, headline, text block, counter, image, and CTA can be customized directly in Elementor without touching code.

---

## 📦 What's Included

```
elementor-kit/
├── templates/
│   ├── 01-header-template.json     # Header with Nav & Light/Dark Theme Switcher
│   ├── 02-footer-template.json     # Footer with Penta Services Credit Bar
│   ├── 03-home-page.json           # Complete Homepage (All 12 sections)
│   ├── 04-about-page.json          # About Us & Mission/Vision
│   ├── 05-services-page.json       # Core Services (Wind, Solar, BESS Storage)
│   ├── 06-portfolio-page.json      # Case Studies & Flagship Projects
│   ├── 07-contact-page.json        # Contact Us & Regional Headquarters
│   └── 08-faq-page.json            # Technical FAQ Accordion
├── theme-support/
│   ├── style.css                   # Theme stylesheet with dark mode variables
│   ├── functions.php               # Enqueue scripts & shortcodes
│   ├── dark-mode-toggle.js         # Interactive Light/Dark theme switcher
│   └── images/brand/
│       └── penta-services-logo.svg # Official Penta Services Logo badge
└── enervox-elementor-template-kit.zip # All-in-one importable zip archive
```

---

## 🚀 Quick Installation Guide (Under 3 Minutes)

### Step 1: Install Hello Elementor Theme
1. In your WordPress Dashboard, go to **Appearance → Themes → Add New**.
2. Search for **Hello Elementor** and click **Install & Activate**.

### Step 2: Install Elementor Plugin
1. Go to **Plugins → Add New Plugin**.
2. Search for **Elementor** and click **Install & Activate** (Free version is fully supported).

### Step 3: Import the Elementor Templates
1. Go to **Templates → Saved Templates** in your WordPress sidebar.
2. Click the **Import Templates** button at the very top.
3. Choose any (or all) JSON files from the `templates/` folder:
   - `01-header-template.json`
   - `02-footer-template.json`
   - `03-home-page.json`
   - `04-about-page.json`
   - `05-services-page.json`
   - `06-portfolio-page.json`
   - `07-contact-page.json`
   - `08-faq-page.json`
4. Click **Import Now**. The templates will now appear in your saved templates list!

### Step 4: Create Pages & Insert Templates
1. Go to **Pages → Add New Page** (e.g. title it `Home`).
2. On the right settings panel under **Page Attributes / Template**, select **Elementor Full Width**.
3. Click **Edit with Elementor**.
4. In the Elementor canvas, click the **gray folder icon** (*Add Template*).
5. Switch to the **My Templates** tab.
6. Find `Enervox - Home Page` and click **Insert** (select *Don't apply* or *Apply* settings when prompted).
7. Click **Publish**!

---

## 🌓 Light / Dark Mode Header Switcher

The header template includes the mandatory **Light / Dark Mode Toggle** with a Moon icon (Light mode) and Sun icon (Dark mode).

To activate the interactive switching and `localStorage` persistence in WordPress:
- **Option A (Child Theme)**: Upload the `theme-support` folder to `/wp-content/themes/enervox-child/` and activate it as a child theme of Hello Elementor.
- **Option B (Code Snippets Plugin)**: Add `dark-mode-toggle.js` into your footer via the **WPCode** or **Simple Custom CSS and JS** plugin.
- **Shortcode**: You can also insert `[enervox_theme_toggle]` anywhere into any Elementor column or widget!

---

## 🏷️ Penta Services Footer Bottom Credit Bar

The footer template incorporates the mandatory **Penta Services credit bottom bar** at the very bottom:
- Official SVG badge linking to `https://pentaservices.co.uk/en/?utm_source=referral&utm_medium=site-credit`
- Tagline: *"Web design, SEO & digital solutions · pentaservices.co.uk"*
- Separator line and responsive styling matching the reference design.
- Shortcode alternative: `[penta_credit_bar]` can be placed in any widget.

---

## 🎨 Global Brand Color Palette

| Name | Hex Code | Description |
| :--- | :--- | :--- |
| **Primary Accent** | `#FF7029` | Enervox Energy vibrant orange |
| **Primary Hover** | `#E65A15` | Darker orange for buttons and links |
| **Dark Navy** | `#2D3239` | Headings, slate cards, and primary text |
| **Dark Background**| `#16191E` | Deep footer and dark mode container background |
| **Light Background**| `#F8FAFC` | Subtle contrast section background |
| **Muted Text** | `#64748B` | Paragraph body copy |
| **Borders** | `#E2E8F0` | Subtle card & input borders |

---

## ✏️ How to Edit Elements in Elementor

1. **Headings & Subtitles**: Click on any heading text on the canvas and edit directly inline or in the left sidebar under *Content → Title*.
2. **Buttons & Links**: Click any button to change text, change URL destination, or change alignment.
3. **Background Images**: Click on a section's **six-dot handle** at the top → go to the *Style* tab → click *Image* to upload your own photos.
4. **Counters & Statistics**: Click on any counter widget to update the ending number (e.g., change `18,000` to `25,000`) and the title.
5. **Progress Bars**: Click any progress bar widget to adjust the percentage slider (e.g. from `85%` to `90%`).
