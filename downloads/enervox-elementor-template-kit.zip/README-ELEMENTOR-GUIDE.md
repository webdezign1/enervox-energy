# Enervox Energy — Elementor WordPress Template Kit

This package converts the **Enervox Energy** clean tech web platform into 100% editable WordPress Elementor templates. Every section, headline, text block, counter, image, and CTA can be customized directly in Elementor without touching code.

---

## 📦 What's Included

```
elementor-kit/
├── templates/
│   ├── 01-header-template.json     # Header with Nav & Light/Dark Theme Switcher
│   ├── 02-footer-template.json     # Footer with Penta Services Credit Bar
│   ├── 03-home-page.json           # Complete Homepage (All 12 sections)
│   ├── 04-about-page.json          # About Us & Mission/Vision
│   ├── 05-services-page.json       # Core Services (Wind, Solar, BESS Storage)
│   ├── 06-portfolio-page.json      # Case Studies & Flagship Projects
│   ├── 07-contact-page.json        # Contact Us & Regional Headquarters
│   └── 08-faq-page.json            # Technical FAQ Accordion
├── theme-support/
│   ├── style.css                   # Theme stylesheet with dark mode variables
│   ├── functions.php               # Enqueue scripts & shortcodes
│   ├── dark-mode-toggle.js         # Interactive Light/Dark theme switcher
│   └── images/brand/
│       └── penta-services-logo.svg # Official Penta Services Logo badge
└── enervox-elementor-template-kit.zip # All-in-one importable zip archive
```

---

## 🚀 Quick Installation Guide

### ✨ Method A: Import ALL Pages in 1 Click (Recommended!)
We provide an all-in-one WordPress XML import file (`enervox-all-pages.xml`) that creates **Home, About Us, Services, Portfolio, Contact Us, and FAQ** automatically with full layouts and images!

1. In WordPress Dashboard, go to **Tools → Import**.
2. Under **WordPress**, click **Install Now** (or **Run Importer** if already installed).
3. Upload `enervox-all-pages.xml` from this package.
4. On the next screen, assign the author to your admin user and click **Submit**.
5. All 6 pages are now created under **Pages → All Pages** with Elementor templates pre-applied!

---

### 📄 Method B: Import Individual Templates (Elementor Library)
If you prefer importing templates individually:

1. Go to **Templates → Saved Templates** in WordPress.
2. Click **Import Templates** at the top.
3. Import the JSON files:
   - `01-header-template.json`
   - `02-footer-template.json`
   - `03-home-page.json`
   - `04-about-page.json`
   - `05-services-page.json`
   - `06-portfolio-page.json`
   - `07-contact-page.json`
   - `08-faq-page.json`
4. To create each page:
   - Go to **Pages → Add New Page**.
   - Title it (e.g., *About Us*, *Services*, *Portfolio*, *Contact Us*, *FAQ*).
   - In the right sidebar under **Page Attributes / Template**, choose **Elementor Full Width**.
   - Click **Publish**, then click **Edit with Elementor**.
   - Click the **gray folder icon** (*Add Template*) → go to **My Templates** → click **Insert** on the matching template.
   - Click **Update**!

---

## 🖼️ Why did images show `placeholder.png`?
* **Why it happened**: Elementor's default image widget requires an attachment ID from your WordPress Media Library. When importing raw JSON templates with external image URLs, Elementor displays a gray placeholder box by default.
* **How this updated kit fixes it**:
  1. All templates have now been updated with **direct responsive image embeds** and **resilient background styling** so that high-resolution clean energy photos display immediately upon import!
  2. You can also click any image widget or section in Elementor, click **Choose Image**, and upload your own custom pictures from your computer anytime!

---

## 🌓 Light / Dark Mode Header Switcher

The header template includes the mandatory **Light / Dark Mode Toggle** with a Moon icon (Light mode) and Sun icon (Dark mode).

To activate the interactive switching and `localStorage` persistence in WordPress:
- **Option A (Child Theme)**: Upload the `theme-support` folder to `/wp-content/themes/enervox-child/` and activate it as a child theme of Hello Elementor.
- **Option B (Code Snippets Plugin)**: Add `dark-mode-toggle.js` into your footer via the **WPCode** or **Simple Custom CSS and JS** plugin.
- **Shortcode**: You can also insert `[enervox_theme_toggle]` anywhere into any Elementor column or widget!

---

## 🏷️ Penta Services Footer Bottom Credit Bar

The footer template incorporates the mandatory **Penta Services credit bottom bar** at the very bottom:
- Official SVG badge linking to `https://pentaservices.co.uk/en/?utm_source=referral&utm_medium=site-credit`
- Tagline: *"Web design, SEO & digital solutions · pentaservices.co.uk"*
- Separator line and responsive styling matching the reference design.
- Shortcode alternative: `[penta_credit_bar]` can be placed in any widget.

---

## 🎨 Global Brand Color Palette

| Name | Hex Code | Description |
| :--- | :--- | :--- |
| **Primary Accent** | `#FF7029` | Enervox Energy vibrant orange |
| **Primary Hover** | `#E65A15` | Darker orange for buttons and links |
| **Dark Navy** | `#2D3239` | Headings, slate cards, and primary text |
| **Dark Background**| `#16191E` | Deep footer and dark mode container background |
| **Light Background**| `#F8FAFC` | Subtle contrast section background |
| **Muted Text** | `#64748B` | Paragraph body copy |
| **Borders** | `#E2E8F0` | Subtle card & input borders |

---

## ✏️ How to Edit Elements in Elementor

1. **Headings & Subtitles**: Click on any heading text on the canvas and edit directly inline or in the left sidebar under *Content → Title*.
2. **Buttons & Links**: Click any button to change text, change URL destination, or change alignment.
3. **Background Images**: Click on a section's **six-dot handle** at the top → go to the *Style* tab → click *Image* to upload your own photos.
4. **Counters & Statistics**: Click on any counter widget to update the ending number (e.g., change `18,000` to `25,000`) and the title.
5. **Progress Bars**: Click any progress bar widget to adjust the percentage slider (e.g. from `85%` to `90%`).
